
alter table sistema.funcionario add sexo boolean;
alter table sistema.funcionario add EstadoCivil int;
alter table sistema.funcionario add racaCor int;
alter table sistema.funcionario add NomePai varchar(100);
alter table sistema.funcionario add NomeMae varchar(100);
alter table sistema.funcionario add nacionalidade varchar(20);
alter table sistema.funcionario add nacionalidadeUF varchar(2);
alter table sistema.funcionario add escolaridade int;
alter table sistema.funcionario add deficiencia int;
alter table sistema.funcionario add deficienciaObservacao varchar(200);

alter table sistema.funcionario add banco varchar(50);
alter table sistema.funcionario add tipoConta boolean;
alter table sistema.funcionario add numeroAgencia varchar(10);
alter table sistema.funcionario add numeroConta varchar(10);










